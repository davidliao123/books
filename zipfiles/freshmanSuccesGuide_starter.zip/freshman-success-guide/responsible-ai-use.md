# Responsible AI Use

This section of the **Freshman Success Guide** will help first-year students use generative AI and other AI tools responsibly, ethically, and effectively in academic work.

> **Student contributor:** Develop the assigned subsection(s) below using clear, specific, and useful advice. Follow the conventions in `STYLE_GUIDE.md` and the workflow in `CONTRIBUTING.md`.

## Start with the Course Policy

<!--
Explain that AI policies may differ across courses, assignments, and instructors.

Possible topics:
- read the syllabus and assignment instructions;
- follow the instructor's stated rules;
- ask for clarification when a policy is unclear;
- do not assume that AI use allowed in one course is allowed in another;
- distinguish between permitted support and prohibited substitution for one's own work.
-->

_To be developed by the assigned contributor._

## Use AI to Support Learning, Not Replace It

<!--
Explain productive ways AI can support learning while preserving student responsibility.

Possible uses:
- asking for an explanation of a difficult concept;
- generating additional practice questions;
- requesting examples;
- brainstorming possible approaches;
- receiving feedback on clarity or organization;
- comparing different ways to solve or explain a problem.

Emphasize that students should still understand, evaluate, and be able to explain the work they submit.
-->

_To be developed by the assigned contributor._

## Verify AI-Generated Information

<!--
Explain that AI-generated answers can be incomplete, misleading, outdated, or incorrect.

Possible verification steps:
1. Compare the response with course notes, textbooks, or official documentation.
2. Check calculations, definitions, citations, links, and factual claims.
3. Test code before relying on it.
4. Confirm important information with an instructor or authoritative source.
5. Do not cite a source that you have not personally checked.
-->

_To be developed by the assigned contributor._

## Protect Private and Sensitive Information

<!--
Explain what students should avoid entering into AI systems.

Possible examples:
- passwords;
- authentication codes;
- private keys;
- access tokens;
- student identification numbers;
- private grades or records;
- confidential research data;
- personally identifiable information about other people;
- unpublished or restricted course materials when sharing is not permitted.

Encourage students to follow university and course policies regarding data privacy.
-->

_To be developed by the assigned contributor._

## AI and Academic Integrity

<!--
Explain the relationship between AI use and academic integrity.

Possible topics:
- submitting AI-generated work as one's own when prohibited;
- using AI during an exam or assessment when not permitted;
- generating answers for assignments intended to measure individual understanding;
- misrepresenting the source of ideas or writing;
- following collaboration and attribution requirements.

Avoid inventing institution-specific rules. Refer students to the official academic-integrity policy and course instructions.
-->

_To be developed by the assigned contributor._

## When and How to Acknowledge AI Use

<!--
Explain that instructors may require students to disclose or document AI assistance.

Possible information to record:
- the AI tool used;
- what the tool was used for;
- what parts of the final work were influenced by AI;
- how the student verified or revised the output.

Follow the instructor's required format. Do not invent a universal citation rule because requirements may vary by course or discipline.
-->

_To be developed by the assigned contributor._

## Responsible AI Use in Writing

<!--
Discuss appropriate and inappropriate uses of AI in writing assignments.

Possible appropriate uses when permitted:
- brainstorming;
- outlining;
- asking for feedback on organization;
- identifying unclear sentences;
- generating questions for revision.

Possible concerns:
- submitting generated prose without understanding it;
- allowing AI to replace the student's own argument or analysis;
- accepting invented sources or quotations;
- changing the student's voice without reviewing the result.

Always follow assignment-specific rules.
-->

_To be developed by the assigned contributor._

## Responsible AI Use in Programming

<!--
Discuss AI assistance in programming courses.

Possible productive uses when permitted:
- explaining an error message;
- describing what a code fragment does;
- suggesting test cases;
- comparing alternative approaches;
- explaining unfamiliar syntax.

Possible risks:
- copying code that the student cannot explain;
- using libraries or functions that were not allowed;
- introducing security or correctness problems;
- submitting generated solutions for work intended to be completed independently.

Students should run, test, read, and understand any code they use.
-->

_To be developed by the assigned contributor._

## Responsible AI Use in Mathematics

<!--
Discuss AI use in mathematics and quantitative courses.

Possible productive uses when permitted:
- requesting another explanation of a concept;
- generating similar practice problems;
- checking an approach after attempting a problem;
- asking for step-by-step clarification.

Possible risks:
- incorrect algebra or arithmetic;
- skipped assumptions;
- invalid proofs;
- plausible-looking but incorrect reasoning;
- relying on an answer without understanding the method.

Students should independently check reasoning and calculations.
-->

_To be developed by the assigned contributor._

## Evaluate AI Suggestions Critically

<!--
Explain that students remain responsible for decisions based on AI output.

Possible questions to ask:
- Does this answer actually address the assignment?
- Is the reasoning correct?
- Are important details missing?
- Can I explain the result in my own words?
- Does the response conflict with course material?
- Are the sources real and relevant?
- Does the response reflect assumptions or bias that should be questioned?
-->

_To be developed by the assigned contributor._

## Avoid Overreliance

<!--
Explain how excessive AI use can interfere with learning.

Possible warning signs:
- asking AI for an answer before attempting the problem;
- accepting explanations without checking understanding;
- depending on AI for every writing or coding task;
- being unable to reproduce or explain submitted work;
- using AI instead of practicing foundational skills.

Encourage students to attempt work independently before seeking AI assistance when appropriate.
-->

_To be developed by the assigned contributor._

## A Responsible AI Workflow

<!--
Develop a simple workflow students can follow when AI use is permitted.

Possible workflow:

1. Read the assignment and AI policy.
2. Attempt the task or identify the specific problem.
3. Use AI for a clearly defined purpose.
4. Review the response critically.
5. Verify important claims, calculations, sources, or code.
6. Revise the work using your own judgment.
7. Document or acknowledge AI use when required.
8. Make sure you can explain the final work yourself.
-->

_To be developed by the assigned contributor._

## Questions to Ask Before Using AI

<!--
Create a short decision checklist.

Possible questions:
- Is AI use allowed for this assignment?
- What specific help do I need?
- Am I sharing any private or restricted information?
- Will I be able to verify the response?
- Am I still doing the intellectual work expected of me?
- Do I need to disclose or cite my AI use?
- Could I explain my final work without the AI tool?
-->

_To be developed by the assigned contributor._

## Key Takeaways

<!--
After the section is complete, summarize 3-5 of the most important habits for responsible AI use.
-->

_To be developed by the assigned contributor._

## Useful Resources

<!--
Add only resources that have been checked for accuracy and relevance.

Example format:
- [Resource Name](https://example.com) — One-sentence explanation of why the resource is useful.

Prefer official university policies, course materials, library guidance, and official documentation. Because AI tools and institutional policies can change, verify time-sensitive information before including it.
-->

_To be developed by the assigned contributor._
