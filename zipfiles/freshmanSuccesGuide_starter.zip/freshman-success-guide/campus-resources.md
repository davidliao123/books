# Campus Resources

This section of the **Freshman Success Guide** will help first-year students identify and use campus resources that support academic success, personal well-being, and college life.

> **Student contributor:** Develop the assigned subsection(s) below using clear, specific, and useful advice. Follow the conventions in `STYLE_GUIDE.md` and the workflow in `CONTRIBUTING.md`.

## Academic Advising

<!--
Explain how academic advising can help students.
Possible topics:
- understanding degree requirements;
- planning a semester schedule;
- preparing for course registration;
- discussing prerequisites;
- reviewing academic progress;
- asking questions about policies or program requirements.

Use institution-specific names, offices, and links only after verifying them.
-->

_To be developed by the assigned contributor._

## Tutoring and Academic Support

<!--
Describe tutoring, supplemental instruction, learning centers, or other academic-support services available to students.
Possible topics:
- what kinds of courses are supported;
- whether appointments are required;
- how to prepare for a tutoring session;
- why students should seek help before falling far behind.

Use verified institution-specific information when available.
-->

_To be developed by the assigned contributor._

## Instructor Office Hours

<!--
Explain how office hours function as an academic resource.
Possible topics:
- asking questions about difficult concepts;
- reviewing feedback on assignments or exams;
- discussing study strategies;
- preparing specific questions before attending;
- using office hours throughout the semester rather than only before an exam.
-->

_To be developed by the assigned contributor._

## Library Resources

<!--
Explain how the campus library can support students.
Possible topics:
- finding books, articles, and databases;
- research assistance;
- quiet or collaborative study spaces;
- technology or equipment lending;
- citation and research support;
- asking a librarian for help.

Include only services that have been verified for the institution.
-->

_To be developed by the assigned contributor._

## Computer Labs and Technology Support

<!--
Describe campus technology resources that may be useful to students.
Possible topics:
- computer labs;
- campus Wi-Fi;
- printing;
- software access;
- account or password support;
- help desk services;
- loaner devices or equipment, if available.

Verify current services before adding details.
-->

_To be developed by the assigned contributor._

## Writing and Communication Support

<!--
Describe resources that help students improve writing, presentations, or communication.
Possible topics:
- writing centers;
- feedback on drafts;
- citation help;
- presentation practice;
- professional or academic communication support.

Explain what students should bring or prepare before using the service.
-->

_To be developed by the assigned contributor._

## Career and Professional Development Resources

<!--
Introduce campus resources that support career development.
Possible topics:
- career counseling;
- resume and cover-letter review;
- internship or job-search support;
- career fairs;
- interview preparation;
- networking events.

For detailed career advice, refer students to career-preparation.md.
-->

_To be developed by the assigned contributor._

## Student Organizations and Peer Communities

<!--
Explain how student organizations and peer communities can help first-year students.
Possible topics:
- academic or professional clubs;
- computing or mathematics organizations;
- mentoring programs;
- study groups;
- opportunities to meet students with similar interests.

Include only verified organizations or describe categories when exact information may change.
-->

_To be developed by the assigned contributor._

## Health, Counseling, and Wellness Resources

<!--
Describe how students can locate appropriate campus health and wellness support.
Possible topics:
- student health services;
- counseling services;
- wellness programs;
- recreation or fitness resources;
- how to find current hours and contact information.

Keep this section focused on how to locate and use campus resources. Do not provide medical or mental-health advice.
For broader discussion of balance and well-being, refer students to health-and-balance.md.
-->

_To be developed by the assigned contributor._

## Accessibility and Accommodation Services

<!--
Explain the role of accessibility or disability-support services.
Possible topics:
- requesting approved academic accommodations;
- where students can learn about eligibility and documentation;
- communicating approved accommodations to instructors;
- beginning the process early when possible.

Use respectful, accurate language and verified institutional information.
-->

_To be developed by the assigned contributor._

## Financial and Basic-Needs Support

<!--
If appropriate for the institution, identify resources that help students with financial or basic needs.
Possible topics:
- financial-aid questions;
- emergency assistance;
- food resources;
- transportation support;
- textbook or technology assistance.

Only include programs and links that have been verified.
-->

_To be developed by the assigned contributor._

## How to Find the Right Resource

<!--
Give practical guidance for students who are unsure where to begin.
Possible steps:
1. Identify the type of problem or question.
2. Check the university website or student portal.
3. Ask an instructor, advisor, or appropriate campus office.
4. Verify office hours, eligibility, and appointment requirements.
5. Follow up if the first resource is not the correct one.
-->

_To be developed by the assigned contributor._

## Key Takeaways

<!--
After the section is complete, summarize 3-5 of the most important ideas about finding and using campus resources.
-->

_To be developed by the assigned contributor._

## Useful Resources

<!--
Add only resources that have been checked for accuracy and relevance.

Example format:
- [Resource Name](https://example.com) — One-sentence explanation of the service or resource.

Prefer official university webpages and other authoritative sources. Because campus services, hours, and contact information can change, verify all institution-specific details before submitting the section.
-->

_To be developed by the assigned contributor._
