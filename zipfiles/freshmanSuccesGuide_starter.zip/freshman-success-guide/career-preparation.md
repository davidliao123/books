# Career Preparation

This section of the **Freshman Success Guide** will help first-year students begin exploring careers, internships, research opportunities, and professional development in Computer Science and Applied Mathematics.

> **Student contributor:** Develop the assigned subsection(s) below using clear, specific, and useful advice. Follow the conventions in `STYLE_GUIDE.md` and the workflow in `CONTRIBUTING.md`.

## Exploring Career Paths

<!--
Help students understand that Computer Science and Applied Mathematics can lead to many different careers.

Possible topics:
- software development;
- data science and analytics;
- cybersecurity;
- artificial intelligence and machine learning;
- quantitative or mathematical modeling;
- research;
- education;
- government or nonprofit work;
- graduate or professional study.

Encourage students to explore several possibilities rather than feeling pressure to choose a career immediately.
-->

_To be developed by the assigned contributor._

## Building Skills During the First Year

<!--
Explain how first-year students can begin developing useful academic and professional skills.

Possible topics:
- strengthening programming and mathematical foundations;
- learning to communicate technical ideas clearly;
- practicing teamwork;
- developing problem-solving habits;
- completing small projects;
- learning commonly used tools;
- reflecting on which types of work they enjoy.
-->

_To be developed by the assigned contributor._

## Creating a Resume

<!--
Give practical guidance for creating an early college resume.

Possible topics:
- education;
- relevant coursework;
- projects;
- technical skills;
- employment;
- volunteer work;
- leadership or student organizations;
- awards or accomplishments.

Explain that first-year students may not yet have extensive technical experience and can improve the resume over time.
-->

_To be developed by the assigned contributor._

## Building a Professional Online Presence

<!--
Explain how students can begin creating a professional online presence.

Possible topics:
- maintaining an appropriate GitHub profile;
- using a professional email address;
- creating a LinkedIn profile if appropriate;
- keeping public information suitable for academic and professional audiences;
- showcasing selected projects or accomplishments.

Remind students not to publish private, sensitive, or confidential information.
-->

_To be developed by the assigned contributor._

## Developing Projects and a Portfolio

<!--
Explain how projects can demonstrate skills and interests.

Possible topics:
- class projects;
- personal programming projects;
- data-analysis projects;
- mathematical investigations;
- collaborative projects;
- research-related work.

Focus on quality, clear documentation, and what the student learned rather than simply accumulating many projects.
-->

_To be developed by the assigned contributor._

## Finding Internships and Other Opportunities

<!--
Introduce students to ways of locating internships and related experiences.

Possible sources:
- university career services;
- faculty members;
- department announcements;
- career fairs;
- employer websites;
- professional organizations;
- research programs;
- campus employment;
- alumni or professional networks.

Explain that application timelines vary and that some opportunities may recruit months in advance.
-->

_To be developed by the assigned contributor._

## Preparing for Career Fairs and Employer Events

<!--
Give concrete preparation steps.

Possible topics:
- review participating organizations in advance;
- identify several employers or organizations of interest;
- prepare a short introduction;
- bring an updated resume when appropriate;
- prepare questions;
- take notes after conversations;
- follow up professionally when appropriate.
-->

_To be developed by the assigned contributor._

## Networking and Building Professional Relationships

<!--
Explain networking in a practical and approachable way.

Possible topics:
- talking with professors;
- meeting alumni;
- attending department events;
- joining student organizations;
- attending professional meetings;
- asking people about their work;
- staying in contact with people who provide useful guidance.

Emphasize that networking is about developing genuine professional relationships, not simply asking people for jobs.
-->

_To be developed by the assigned contributor._

## Preparing for Interviews

<!--
Introduce basic interview preparation.

Possible topics:
- researching the organization;
- reviewing the job or internship description;
- preparing examples from classes, projects, work, or activities;
- practicing behavioral questions;
- reviewing technical fundamentals when relevant;
- preparing questions for the interviewer;
- testing technology before a virtual interview.
-->

_To be developed by the assigned contributor._

## Exploring Undergraduate Research

<!--
Explain how students can begin learning about research opportunities.

Possible topics:
- reading faculty research interests;
- attending research presentations;
- asking professors about their work;
- developing foundational skills before applying;
- looking for university research programs;
- understanding that some opportunities may be available later in the undergraduate program.

Use verified department or university information when adding specific programs.
-->

_To be developed by the assigned contributor._

## Considering Graduate or Professional School

<!--
Provide a brief introduction for students who may eventually consider further study.

Possible topics:
- learning about graduate degrees;
- maintaining strong academic foundations;
- gaining research or project experience;
- speaking with faculty and advisors;
- exploring career goals before deciding.

This section should introduce the topic rather than pressure first-year students to make an early decision.
-->

_To be developed by the assigned contributor._

## Using Career Services

<!--
Describe how the institution's career services office can support students.

Possible services:
- resume reviews;
- internship and job searches;
- career counseling;
- interview preparation;
- career fairs;
- employer events;
- networking support.

Use institution-specific names, locations, and links only after verifying them.
-->

_To be developed by the assigned contributor._

## A First-Year Career Checklist

<!--
Create a realistic checklist of actions a first-year student could complete.

Possible examples:
- create a basic resume;
- create or update a GitHub profile;
- attend one career or department event;
- speak with a professor about an area of interest;
- explore several possible career paths;
- complete at least one project worth discussing;
- learn where the university posts internships and research opportunities.

Keep expectations realistic for a first-year student.
-->

_To be developed by the assigned contributor._

## Key Takeaways

<!--
After the section is complete, summarize 3-5 of the most important career-preparation actions for first-year students.
-->

_To be developed by the assigned contributor._

## Useful Resources

<!--
Add only resources that have been checked for accuracy and relevance.

Example format:
- [Resource Name](https://example.com) — One-sentence explanation of why the resource is useful.

Prefer official university career resources, professional organizations, employer websites, and other authoritative sources when possible. Verify time-sensitive information such as application deadlines before including it.
-->

_To be developed by the assigned contributor._
