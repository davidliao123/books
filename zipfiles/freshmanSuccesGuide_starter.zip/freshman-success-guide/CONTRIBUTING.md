# Contributing to the Freshman Success Guide

Thank you for contributing to the **Freshman Success Guide**. This repository is a collaborative class project designed to help future first-year students while giving current students practice with Git, GitHub, Markdown, pull requests, peer review, and merging.

Follow the workflow and expectations below unless your instructor gives different directions.

## Before You Begin

Before making changes:

- confirm that you can access the class repository;
- verify that Git is installed on your computer;
- verify that Visual Studio Code or your approved editor is available;
- confirm your Git name and email configuration;
- identify your assigned Markdown file or section;
- read `README.md`;
- read `STYLE_GUIDE.md`;
- review any assignment-specific instructions from your instructor.

Do not begin editing until you understand the scope of your assigned contribution.

## Work Only in Your Assigned Scope

Each student will be assigned a Markdown file, section, or topic.

Unless your instructor or reviewer asks you to do otherwise:

- edit only your assigned file or section;
- do not rename files;
- do not delete files;
- do not reorganize the repository;
- do not modify another student's assigned section;
- do not make unrelated changes while completing your assignment.

Keeping each contribution focused makes changes easier to review and reduces the chance of conflicts.

## Do Not Edit `main` Directly

The `main` branch represents the shared version of the guide.

Do not make your project contribution directly on `main` unless your instructor specifically tells you to do so.

Instead, create and work on a separate branch for your assigned contribution.

A branch name should be short and descriptive. Examples include:

```text
study-strategies
campus-resources
career-preparation
responsible-ai
```

Your instructor may require a particular branch-naming format.

## Recommended Workflow

Use the following workflow for your contribution:

```text
Clone → Pull → Branch → Edit → Review → Commit → Push → Pull Request → Peer Review → Revise → Merge
```

### 1. Clone the Repository

Create a local copy of the class repository on your computer using the method demonstrated by your instructor.

### 2. Pull Recent Changes

Before beginning new work, make sure your local repository includes recent changes from the shared repository.

### 3. Create a Branch

Create a separate branch for your assigned contribution.

### 4. Edit Your Assigned Content

Open the repository in Visual Studio Code or another instructor-approved editor.

Follow the guidance in `STYLE_GUIDE.md`.

Your contribution should be:

- accurate;
- useful to first-year students;
- specific rather than vague;
- clearly organized;
- written in an appropriate academic and professional tone;
- consistent with the rest of the guide.

### 5. Review Your Changes

Before creating a commit:

- reread your contribution;
- check spelling and grammar;
- check Markdown formatting;
- verify links;
- confirm that you changed only the intended content;
- inspect the differences shown by Git or Visual Studio Code.

### 6. Create Meaningful Commits

A commit should represent a meaningful completed change.

Good commit messages describe what changed.

Examples:

```text
Add exam preparation strategies
Add campus tutoring resources
Revise career fair preparation section
Fix broken advising link
Clarify responsible AI guidelines
```

Avoid vague commit messages such as:

```text
update
changes
stuff
final
final2
```

You may make more than one commit while completing your contribution.

## Push Your Branch

When your work is ready to share, push your branch to GitHub.

Pushing your branch does not automatically add your changes to `main`. It makes the branch available on GitHub so that you can open a pull request.

## Open a Pull Request

Create a pull request when your contribution is ready for review.

The pull request should:

- use a clear title;
- identify the file or section you changed;
- briefly explain what you added or revised;
- mention anything the reviewer should check carefully;
- complete the checklist provided in the pull request template.

Do not merge your own pull request unless your instructor has authorized you to do so.

## Participate in Peer Review

A classmate may be assigned to review your pull request.

Reviewers should focus on the contribution rather than the contributor.

Useful review comments may identify:

- unclear wording;
- missing explanations;
- inaccurate information;
- inconsistent formatting;
- broken or questionable links;
- information that needs verification;
- sections that do not match the assigned scope.

Review comments should be specific, respectful, and actionable.

## Respond to Review Feedback

If your reviewer requests changes:

1. read each comment carefully;
2. decide what needs to be revised;
3. make the changes on the same branch;
4. commit the revisions;
5. push the branch again;
6. respond to review comments when appropriate.

The pull request will update automatically when additional commits are pushed to the same branch.

Do not open a new pull request simply because revisions were requested.

## Merging

A contribution should be merged only after the required review and approval process is complete.

Your instructor will determine who is permitted to merge pull requests.

After a contribution is merged, verify that the changes appear correctly in the `main` branch.

## Writing and Formatting Expectations

Follow `STYLE_GUIDE.md` for detailed Markdown and writing conventions.

In general:

- use clear headings;
- write short, readable paragraphs;
- use lists when they improve clarity;
- give practical advice rather than unsupported general statements;
- use descriptive link text;
- verify external links;
- use institution-specific information only when it has been checked;
- keep the intended first-year audience in mind.

## Sources and Accuracy

You are responsible for checking the accuracy of the information you contribute.

When adding factual or institution-specific information:

- prefer official university or department sources;
- verify current office names, services, policies, and links;
- verify deadlines or other time-sensitive information;
- do not invent details when information cannot be confirmed;
- follow any source or citation requirements given by your instructor.

If you are unsure whether information is accurate, ask your instructor or reviewer before including it.

## Images and Other Files

Do not add images or other files unless they are part of your assignment or have been approved.

If images are permitted:

- place them in the `images/` folder;
- use descriptive filenames;
- follow the project's accessibility and formatting requirements;
- do not upload copyrighted material without permission;
- do not upload unnecessarily large files.

## Sensitive Information

Never commit sensitive information to the repository.

Do not include:

- passwords;
- authentication codes;
- access tokens;
- private keys;
- recovery codes;
- student identification numbers;
- private grades;
- confidential records;
- private personal information about another person.

If sensitive information is accidentally committed, notify your instructor immediately. Simply deleting it in a later commit may not remove it from repository history.

## Files You Should Not Add

Do not commit temporary, personal, or unrelated files.

Examples may include:

```text
.DS_Store
Thumbs.db
temporary notes
personal backups
unrelated downloads
```

The repository's `.gitignore` file may automatically exclude some unnecessary files.

## If You Are Unsure What Git Is Doing

Use:

```text
git status
```

as your first diagnostic step.

It can help you identify:

- your current branch;
- changed files;
- staged files;
- untracked files;
- whether there are changes waiting to be committed.

If you are still unsure, stop before making destructive changes and ask your instructor for help.

## Before Submitting Your Pull Request

Confirm that:

- [ ] I worked on the correct branch.
- [ ] I changed only my assigned file or section.
- [ ] My contribution follows `STYLE_GUIDE.md`.
- [ ] I reviewed my Markdown formatting.
- [ ] I checked spelling and grammar.
- [ ] I verified links and factual information.
- [ ] I inspected the changes before committing.
- [ ] My commit messages describe meaningful changes.
- [ ] I pushed the correct branch to GitHub.
- [ ] I did not include private or sensitive information.
- [ ] My contribution is ready for peer review.

## Questions

If any instruction is unclear, ask your instructor before making changes that could affect other contributors or the shared repository.
