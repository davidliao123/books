# Pull Request: Freshman Success Guide Contribution

## What Did You Change?

<!--
Briefly describe the contribution in 1-3 sentences.

Example:
Added practical exam-preparation strategies to the Study Strategies section and revised the weekly planning subsection for clarity.
-->

_To be completed by the contributor._

## Assigned File or Section

<!--
Identify the file and, when applicable, the specific section or topic you were assigned.

Example:
File: study-strategies.md
Section: Studying for Exams
-->

**File:**  
**Section or topic:**  

## Why Is This Change Useful?

<!--
Explain how the change helps future first-year students.

Focus on the purpose of the contribution rather than simply repeating what was edited.
-->

_To be completed by the contributor._

## What Should the Reviewer Check?

<!--
Mention anything that deserves particular attention.

Examples:
- clarity of the advice;
- accuracy of campus information;
- Markdown formatting;
- organization;
- external links;
- whether the section fits the intended audience.
-->

_To be completed by the contributor._

## Contributor Checklist

Before requesting review, confirm that:

- [ ] I worked on the correct branch.
- [ ] I changed only my assigned file or section unless otherwise instructed.
- [ ] I followed `STYLE_GUIDE.md`.
- [ ] I reviewed my Markdown formatting.
- [ ] I checked spelling and grammar.
- [ ] I verified factual and institution-specific information.
- [ ] I opened and checked every external link I added.
- [ ] I inspected my changes before committing.
- [ ] My commit messages describe meaningful changes.
- [ ] I did not include passwords, authentication codes, tokens, private keys, grades, or other sensitive information.
- [ ] I removed placeholder text from the section I completed.
- [ ] I am ready for peer review.

## Reviewer Checklist

<!--
The assigned reviewer may use this checklist when evaluating the contribution.
-->

- [ ] The contribution matches the assigned scope.
- [ ] The writing is clear and useful for first-year students.
- [ ] The advice is specific rather than vague.
- [ ] The organization and headings are easy to follow.
- [ ] Markdown formatting is consistent with the project style guide.
- [ ] Links appear relevant and work correctly.
- [ ] Factual or institution-specific claims appear properly verified.
- [ ] The contribution does not unnecessarily repeat another section.
- [ ] No private or sensitive information is included.
- [ ] The contribution is ready to merge, or specific revisions have been requested.

## Review Notes

<!--
Reviewer: add concise, specific, and actionable feedback when changes are needed.

Contributor: respond to review comments and push revisions to the same branch. Do not open a new pull request unless your instructor directs you to do so.
-->

_No review notes yet._
