# Contributors

This page records the students who contributed to the **Freshman Success Guide** and identifies the sections they helped develop.

> **Student contributor:** Add or update your information only as directed by your instructor. Follow the conventions in `STYLE_GUIDE.md` and the workflow in `CONTRIBUTING.md`.

## How to Add Your Contribution

<!--
When your instructor asks you to update this file, add your information to the table below.

Use the name and GitHub username you are comfortable displaying to the class. Do not include private contact information such as personal phone numbers, home addresses, passwords, authentication codes, or other sensitive information.
-->

Add one row using this format:

```markdown
| Your Name | your-github-username | academics.md | Academic Advising |
```

## Contributor List

| Contributor | GitHub Username | File | Section or Topic |
|---|---|---|---|
| _To be added_ | _To be added_ | _To be added_ | _To be added_ |

## Contribution Guidelines

When updating this file:

- use your preferred academic or professional name;
- enter the GitHub username used for this class project;
- list the Markdown file you contributed to;
- identify the specific section or topic when applicable;
- keep entries brief and consistent;
- do not remove or change another contributor's entry unless instructed to do so;
- do not include grades, student identification numbers, private email addresses, or other sensitive information.

## Acknowledgments

The Freshman Success Guide is a collaborative class project. Each contribution becomes part of a shared resource intended to help future first-year students in Computer Science and Applied Mathematics.

Contributors are responsible not only for the content they create, but also for participating in the Git and GitHub workflow used to review and combine that work.
