# Tools and Software

This section of the **Freshman Success Guide** will help first-year students identify useful software and digital tools for coursework, organization, communication, programming, mathematics, and collaboration.

> **Student contributor:** Develop the assigned subsection(s) below using clear, specific, and useful advice. Follow the conventions in `STYLE_GUIDE.md` and the workflow in `CONTRIBUTING.md`.

## Organizing Your Digital Work

<!--
Explain how students can organize files and coursework so that materials are easy to find.

Possible topics:
- creating folders for each course;
- using clear filenames;
- separating current work from archived work;
- avoiding many confusing copies such as final, final2, and final-new;
- keeping important documents in reliable locations;
- maintaining a consistent organizational system.
-->

_To be developed by the assigned contributor._

## Calendar and Task-Management Tools

<!--
Explain how digital calendars and task-management tools can help students manage deadlines.

Possible topics:
- entering exam dates and major assignments;
- scheduling recurring study blocks;
- setting reminders;
- breaking large assignments into smaller tasks;
- reviewing the upcoming week regularly.

Avoid recommending a large number of competing tools. Focus on useful practices first, then give a few examples when appropriate.
-->

_To be developed by the assigned contributor._

## Cloud Storage and File Synchronization

<!--
Explain the benefits and limitations of cloud storage.

Possible topics:
- accessing files across devices;
- reducing the risk of losing work when a device fails;
- sharing files when appropriate;
- understanding synchronization;
- avoiding accidental overwrites;
- protecting private or sensitive information.

Use institution-provided storage services when appropriate and verify any institution-specific recommendations.
-->

_To be developed by the assigned contributor._

## Communication Tools

<!--
Describe common tools students may use to communicate with instructors, classmates, and project teams.

Possible topics:
- university email;
- the learning management system;
- course discussion tools;
- approved messaging or collaboration platforms;
- professional communication habits;
- checking official course communication regularly.

Emphasize that students should follow instructor and institutional expectations about which communication channels to use.
-->

_To be developed by the assigned contributor._

## Visual Studio Code

<!--
Introduce Visual Studio Code as a tool students may use for programming, Markdown, and Git-related work.

Possible topics:
- opening project folders;
- editing text and source-code files;
- using the integrated terminal;
- using Source Control;
- installing only necessary extensions;
- keeping the editor updated.

Do not turn this section into a full VS Code tutorial.
-->

_To be developed by the assigned contributor._

## Git and GitHub

<!--
Give a brief practical explanation of Git and GitHub as tools students may encounter in coursework and projects.

Possible topics:
- Git for recording project history;
- GitHub for hosting and collaboration;
- commits;
- branches;
- pull requests;
- reviewing changes;
- using version control instead of creating many manually renamed copies.

Detailed Git and GitHub instructions belong in the course booklet rather than this guide.
-->

_To be developed by the assigned contributor._

## Programming Tools

<!--
Describe categories of software that may be useful in programming courses.

Possible topics:
- code editors or integrated development environments;
- terminals and command-line tools;
- language runtimes or interpreters;
- package managers;
- debugging tools;
- browser developer tools.

Avoid assuming that every course uses the same programming language or software. Follow course-specific instructions.
-->

_To be developed by the assigned contributor._

## Mathematics and Data Tools

<!--
Describe software that may support mathematics, statistics, visualization, or data analysis.

Possible topics:
- graphing tools;
- symbolic mathematics systems;
- spreadsheets;
- statistical software;
- programming environments;
- notebook tools.

Emphasize that software should support mathematical reasoning rather than replace understanding of the underlying concepts.
-->

_To be developed by the assigned contributor._

## Note-Taking and Document Tools

<!--
Discuss digital tools for notes, reports, and other academic documents.

Possible topics:
- word processors;
- Markdown;
- PDF annotation;
- note-taking applications;
- organizing course notes;
- exporting or submitting documents in required formats.

Remind students to follow instructor requirements for file formats and submission methods.
-->

_To be developed by the assigned contributor._

## Collaboration Tools

<!--
Explain how software can support group work.

Possible topics:
- shared documents;
- version control;
- team communication;
- shared calendars;
- task boards;
- collaborative whiteboards;
- clearly assigning responsibilities.

Focus on choosing tools that match the needs of the project instead of using software simply because it is popular.
-->

_To be developed by the assigned contributor._

## Passwords and Account Security

<!--
Provide basic digital-safety guidance.

Possible topics:
- using strong, unique passwords;
- using a password manager when appropriate;
- enabling multi-factor authentication;
- recognizing suspicious login requests;
- protecting recovery codes;
- signing out of shared devices.

Do not include passwords, access tokens, private keys, authentication codes, or other credentials in this repository.
-->

_To be developed by the assigned contributor._

## Backups and Protecting Your Work

<!--
Explain practical ways students can reduce the risk of losing academic work.

Possible topics:
- keeping important files in more than one reliable location;
- understanding cloud synchronization versus backup;
- using version history when available;
- saving work regularly;
- checking that important files can actually be recovered;
- avoiding dependence on a single device.
-->

_To be developed by the assigned contributor._

## Choosing the Right Tool

<!--
Help students evaluate whether a tool is appropriate for a task.

Possible questions:
- Does the instructor require a specific tool?
- Is the tool supported by the university?
- Does it work on the student's device?
- Is the student's data private and secure?
- Is the tool free or does it require payment?
- Will classmates need access?
- Is a simpler tool sufficient?
-->

_To be developed by the assigned contributor._

## Key Takeaways

<!--
After the section is complete, summarize 3-5 of the most important habits for choosing and using academic technology effectively.
-->

_To be developed by the assigned contributor._

## Useful Resources

<!--
Add only resources that have been checked for accuracy and relevance.

Example format:
- [Resource Name](https://example.com) — One-sentence explanation of why the resource is useful.

Prefer official university technology resources and official software documentation when possible. Software features, pricing, and installation instructions can change, so verify current information before including it.
-->

_To be developed by the assigned contributor._
