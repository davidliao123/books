# Section Title

<!--
Replace "Section Title" with the title of your assigned section or topic.

Use this template only when your instructor asks you to create a new section or provides it as the starting point for your assigned work.

Before editing:
- read README.md;
- read CONTRIBUTING.md;
- read STYLE_GUIDE.md;
- confirm the scope of your assignment;
- follow any additional instructor directions.
-->

Write a short introduction that explains what this section covers and why it is useful to first-year students.

## Main Topic 1

<!--
Replace this heading with a clear, descriptive heading.

Provide practical, specific advice. Explain what the reader should do rather than giving only general statements.

When appropriate:
- give concrete examples;
- explain steps in order;
- use bullet lists for related items;
- use numbered lists when sequence matters;
- verify factual and institution-specific information.
-->

_To be developed by the assigned contributor._

## Main Topic 2

<!--
Replace this heading with another major topic related to your assigned section.

Keep paragraphs focused and readable. Avoid repeating material that already appears elsewhere in the guide. Link to another guide file when that topic is covered in more detail.
-->

_To be developed by the assigned contributor._

## Main Topic 3

<!--
Add, remove, or rename major topic sections only as appropriate for your assignment and instructor directions.

If you need a subsection, use a level-three heading:

### Subtopic

Do not skip heading levels.
-->

_To be developed by the assigned contributor._

## Practical Tips

<!--
Use this section when a short list of actionable recommendations would help the reader.

Example structure:

- Begin with a specific action.
- Explain why or when the action is useful.
- Keep each item concise.
- Avoid vague advice.
-->

_To be developed by the assigned contributor._

## Common Mistakes to Avoid

<!--
Use this section only when it adds value.

Identify realistic mistakes a first-year student might make and explain how to avoid them. Keep the tone constructive rather than judgmental.
-->

_To be developed by the assigned contributor._

## What to Do If You Need Help

<!--
When relevant, explain where students can go for additional help.

Possible examples:
- instructor office hours;
- academic advising;
- tutoring;
- career services;
- technology support;
- other verified campus resources.

For detailed campus support information, link to campus-resources.md when appropriate.
-->

_To be developed by the assigned contributor._

## Key Takeaways

<!--
Summarize 3-5 of the most useful ideas from the completed section.

Keep this concise and action-oriented.
-->

_To be developed by the assigned contributor._

## Useful Resources

<!--
Add only resources that you have personally checked for accuracy and relevance.

Use descriptive link text.

Example:

- [Resource Name](https://example.com) — One-sentence explanation of why the resource is useful.

Prefer official university, department, government, professional-organization, or official software sources when appropriate.

Verify time-sensitive information before submitting your contribution.
-->

_To be developed by the assigned contributor._
