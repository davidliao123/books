# Freshman Success Guide

Welcome to the **Freshman Success Guide**, a collaborative class project created to help future first-year students in **Computer Science and Applied Mathematics** succeed in college.

This repository has two goals:

1. Create a useful, accurate, and clearly written guide for future students.
2. Practice a complete collaborative workflow using **Git, GitHub, Markdown, branches, commits, pull requests, peer review, and merging**.

## Guide Sections

The guide is organized into the following sections:

- [Academics](academics.md)
- [Study Strategies](study-strategies.md)
- [Campus Resources](campus-resources.md)
- [Career Preparation](career-preparation.md)
- [Tools and Software](tools-and-software.md)
- [Responsible AI Use](responsible-ai-use.md)
- [Health and Balance](health-and-balance.md)
- [Contributors](contributors.md)

## Intended Audience

This guide is written for future first-year students in Computer Science and Applied Mathematics.

Contributions should be practical, specific, and useful. Instead of giving only general advice, explain what a student can actually do.

For example, instead of writing:

> Manage your time effectively.

Explain concrete strategies such as:

- how to break a weekly assignment into smaller tasks;
- when to begin preparing for an exam;
- how to use instructor office hours;
- how to organize recurring deadlines;
- what to do after falling behind.

## Project Workflow

During this project, contributors will use the following workflow:

**Clone → Branch → Edit → Commit → Push → Pull Request → Review → Merge**

Each student will work on an assigned Markdown file or section. Do not edit another student's assigned work unless your instructor or reviewer asks you to do so.

## Contribution Expectations

When contributing to this guide:

- work only in your assigned file or section unless instructed otherwise;
- follow the project's Markdown and writing conventions;
- write for a first-year student audience;
- provide accurate and useful information;
- verify links and resources before submitting them;
- make meaningful commits that describe completed changes;
- submit your work through a pull request;
- participate in peer review and respond to requested revisions;
- do not add passwords, authentication codes, tokens, private keys, or other sensitive information.

Detailed contribution instructions are provided in [CONTRIBUTING.md](CONTRIBUTING.md).

Writing and formatting conventions are provided in [STYLE_GUIDE.md](STYLE_GUIDE.md).

## Repository Organization

```text
freshman-success-guide/
├── README.md
├── academics.md
├── study-strategies.md
├── campus-resources.md
├── career-preparation.md
├── tools-and-software.md
├── responsible-ai-use.md
├── health-and-balance.md
├── contributors.md
├── CONTRIBUTING.md
├── STYLE_GUIDE.md
├── .gitignore
├── images/
├── resources/
├── templates/
└── .github/
```

## Working with the Repository

At the beginning of the project, use the GitHub website to examine the repository, read this README, and locate your assigned section.

Do not begin editing files on the main project page unless your instructor directs you to do so. You will learn the required workflow before making project changes.

## Contributors

See [contributors.md](contributors.md) for the class contribution record.

## Acknowledgments

This guide is developed collaboratively by students as part of the Freshman Seminar Git and GitHub project. The goal is to leave future students with practical advice while giving current students experience with collaborative version control.
