# Academics

This section of the **Freshman Success Guide** will provide practical advice for first-year students in Computer Science and Applied Mathematics as they adjust to college-level academic expectations.

> **Student contributor:** Develop the assigned subsection(s) below using clear, specific, and useful advice. Follow the conventions in `STYLE_GUIDE.md` and the workflow in `CONTRIBUTING.md`.

## Understanding College-Level Expectations

<!--
Explain how college courses may differ from high school courses.
Possible topics:
- greater responsibility for keeping track of assignments and deadlines;
- faster pacing;
- more independent learning;
- expectations for reading, practice, and preparation outside class;
- asking questions before small problems become larger ones.
-->

_To be developed by the assigned contributor._

## Attending and Preparing for Class

<!--
Provide practical guidance about:
- attending class consistently;
- checking the syllabus and course announcements;
- completing assigned reading or preparation;
- bringing needed materials;
- reviewing notes after class.
-->

_To be developed by the assigned contributor._

## Using the Course Syllabus

<!--
Explain how students can use a syllabus as a planning tool.
Possible topics:
- instructor contact information;
- office hours;
- grading policies;
- attendance policies;
- major assignments and exams;
- course resources;
- academic-integrity expectations.
-->

_To be developed by the assigned contributor._

## Communicating with Instructors

<!--
Give specific advice for communicating professionally with instructors.
Possible topics:
- asking questions in class;
- sending clear email messages;
- requesting clarification;
- discussing academic concerns early;
- preparing before meeting with an instructor.
-->

_To be developed by the assigned contributor._

## Using Office Hours

<!--
Explain what office hours are and how students can use them effectively.
Possible examples:
- asking about a concept that is still unclear;
- reviewing an incorrect solution;
- getting feedback on study approaches;
- discussing how to improve after a poor exam or assignment.
-->

_To be developed by the assigned contributor._

## Academic Advising

<!--
Explain the role of academic advising.
Possible topics:
- planning a semester schedule;
- understanding program requirements;
- discussing prerequisites;
- preparing for registration;
- asking about academic policies or degree progress.

Use institution-specific information only when it has been verified.
-->

_To be developed by the assigned contributor._

## Keeping Track of Deadlines

<!--
Provide concrete methods students can use to manage academic deadlines.
Possible topics:
- entering major dates into a calendar;
- checking the learning management system regularly;
- breaking large assignments into smaller tasks;
- planning backward from exams and project deadlines.
-->

_To be developed by the assigned contributor._

## When You Are Struggling Academically

<!--
Give practical next steps rather than general encouragement.
Possible actions:
- identify which course or topic is causing difficulty;
- review feedback on recent work;
- contact the instructor;
- attend office hours;
- use tutoring or other academic-support resources;
- revise the weekly study schedule;
- seek help early rather than waiting until the end of the semester.

Refer students to campus-resources.md when appropriate.
-->

_To be developed by the assigned contributor._

## Key Takeaways

<!--
After the section is complete, summarize 3-5 of the most important academic habits for first-year students.
-->

_To be developed by the assigned contributor._

## Useful Resources

<!--
Add only resources that have been checked for accuracy and relevance.

Example format:
- [Resource Name](https://example.com) — One-sentence explanation of why the resource is useful.

Prefer official university, department, course, or other authoritative resources when possible.
-->

_To be developed by the assigned contributor._
