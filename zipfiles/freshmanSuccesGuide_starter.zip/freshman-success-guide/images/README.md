# Images

This folder contains images used in the **Freshman Success Guide**.

> **Student contributor:** Add images only when they are part of your assigned work or have been approved by your instructor. Follow the project conventions in `STYLE_GUIDE.md` and the workflow in `CONTRIBUTING.md`.

## Before Adding an Image

Before adding an image:

- confirm that the image is necessary;
- make sure you have permission to use it;
- verify that it supports the content of the guide;
- use a clear, descriptive filename;
- keep the file size reasonable;
- follow any instructor requirements for image format or dimensions.

Do not add decorative images that do not improve the usefulness of the guide.

## File Names

Use lowercase letters and hyphens in image filenames.

Prefer:

```text
weekly-study-schedule.png
campus-map-example.png
career-fair-checklist.png
```

Avoid:

```text
image1.png
Screenshot123.png
final-image-new.png
```

The filename should briefly describe what the image contains.

## Supported Formats

Use common web-friendly image formats such as:

```text
.png
.jpg
.jpeg
.webp
```

Use the format requested by your instructor when specific requirements apply.

Avoid unnecessarily large image files.

## Adding an Image to Markdown

Use standard Markdown image syntax:

```markdown
![Alternative text](images/example-image.png)
```

If you are linking from a Markdown file in the repository root, the path will usually begin with:

```text
images/
```

For example:

```markdown
![Example of a weekly study schedule](images/weekly-study-schedule.png)
```

## Alternative Text

Every meaningful image should include useful alternative text.

Alternative text should briefly communicate the purpose or important content of the image.

Prefer:

```markdown
![Example of a weekly study schedule with study blocks distributed across five weekdays](images/weekly-study-schedule.png)
```

Avoid:

```markdown
![image](images/weekly-study-schedule.png)
```

or:

```markdown
![weekly-study-schedule.png](images/weekly-study-schedule.png)
```

Do not use the filename as alternative text unless it genuinely describes the image.

## Accessibility

When creating or selecting images:

- do not rely only on color to communicate meaning;
- use readable text and sufficient contrast;
- keep diagrams simple and clearly labeled;
- provide meaningful alternative text;
- avoid placing essential information only inside an image when the same information should also appear in the surrounding text.

## Copyright and Permissions

Do not upload an image simply because it appears online.

Before adding an image, make sure it is:

- created by you;
- provided or approved by your instructor;
- licensed for the intended use; or
- otherwise permitted for inclusion in the project.

When attribution is required, follow the instructor's directions for providing it.

## Screenshots

Use screenshots only when they clearly support the guide.

Before adding a screenshot:

- remove or hide private information;
- check for names, email addresses, account information, grades, notifications, or other sensitive details;
- crop unnecessary areas;
- make sure the screenshot is readable;
- verify that the interface shown is still current when that matters.

Do not include passwords, authentication codes, access tokens, private messages, or other sensitive information.

## Replacing an Existing Image

Do not replace or delete another contributor's image unless:

- it is part of your assigned work;
- your reviewer requests the change; or
- your instructor approves it.

If an image needs revision, keep the existing filename when appropriate so that Markdown links do not break.

## Before Committing an Image

Confirm that:

- [ ] The image is relevant to my assigned contribution.
- [ ] I have permission to use it.
- [ ] The filename is descriptive.
- [ ] The file is stored in the `images/` folder.
- [ ] The file size is reasonable.
- [ ] The image is referenced correctly in Markdown.
- [ ] The alternative text is meaningful.
- [ ] The image does not expose private or sensitive information.
- [ ] I previewed the Markdown to confirm that the image displays correctly.
