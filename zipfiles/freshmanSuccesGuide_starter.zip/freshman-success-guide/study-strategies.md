# Study Strategies

This section of the **Freshman Success Guide** will provide practical study strategies for first-year students in Computer Science and Applied Mathematics.

> **Student contributor:** Develop the assigned subsection(s) below using clear, specific, and useful advice. Follow the conventions in `STYLE_GUIDE.md` and the workflow in `CONTRIBUTING.md`.

## Building a Weekly Study Routine

<!--
Explain how students can create a realistic weekly study routine.
Possible topics:
- reviewing the week's assignments and deadlines;
- scheduling regular study blocks;
- balancing coursework across several classes;
- leaving extra time for difficult or unexpected work;
- adjusting the plan when priorities change.
-->

_To be developed by the assigned contributor._

## Breaking Large Assignments into Smaller Tasks

<!--
Give a concrete method for dividing a large assignment into manageable steps.
Possible examples:
- read the assignment;
- identify requirements;
- create a task list;
- estimate time for each task;
- set intermediate deadlines;
- review the completed work before submission.
-->

_To be developed by the assigned contributor._

## Studying for Exams

<!--
Provide specific guidance for preparing for exams.
Possible topics:
- beginning preparation several days in advance;
- identifying topics that need more practice;
- reviewing notes and examples;
- solving practice problems without looking at solutions;
- explaining concepts in your own words;
- asking questions before the exam.
-->

_To be developed by the assigned contributor._

## Studying for Mathematics Courses

<!--
Focus on strategies that are especially useful in mathematics.
Possible topics:
- practicing problems regularly rather than only rereading notes;
- showing all steps;
- checking incorrect solutions;
- identifying where reasoning went wrong;
- learning definitions and notation;
- using office hours or tutoring when a concept remains unclear.
-->

_To be developed by the assigned contributor._

## Studying for Programming Courses

<!--
Focus on strategies that are especially useful in programming courses.
Possible topics:
- writing and running code frequently;
- tracing code by hand;
- testing small parts before building larger solutions;
- reading error messages carefully;
- comparing expected and actual output;
- avoiding last-minute programming assignments.
-->

_To be developed by the assigned contributor._

## Taking and Reviewing Notes

<!--
Explain how students can make class notes more useful.
Possible topics:
- recording key ideas rather than every word;
- marking examples or concepts that are unclear;
- reviewing notes soon after class;
- adding missing explanations while the material is still fresh;
- connecting notes to textbook examples, assignments, or practice problems.
-->

_To be developed by the assigned contributor._

## Using Active Study Methods

<!--
Explain the difference between passive review and active practice.
Possible active methods:
- self-quizzing;
- practice problems;
- flashcards when appropriate;
- explaining a concept without notes;
- creating examples;
- teaching the idea to a classmate;
- recalling information before checking the answer.
-->

_To be developed by the assigned contributor._

## Avoiding Common Study Mistakes

<!--
Identify common habits that may feel productive but are often insufficient on their own.
Possible examples:
- rereading without testing understanding;
- highlighting large amounts of text;
- studying only the night before an exam;
- spending too much time on material already understood;
- ignoring mistakes instead of analyzing them.
-->

_To be developed by the assigned contributor._

## Studying with Other Students

<!--
Provide guidance for productive group study.
Possible topics:
- arriving prepared;
- choosing a specific goal for the session;
- comparing reasoning rather than copying answers;
- taking turns explaining concepts;
- respecting course collaboration and academic-integrity policies.
-->

_To be developed by the assigned contributor._

## What to Do When You Fall Behind

<!--
Give concrete steps students can take after missing work or getting behind.
Possible actions:
- identify the most urgent deadlines;
- determine what can still be completed;
- contact the instructor when appropriate;
- create a short recovery plan;
- use office hours, tutoring, or other support;
- avoid trying to fix everything at once without prioritizing.
-->

_To be developed by the assigned contributor._

## Key Takeaways

<!--
After the section is complete, summarize 3-5 of the most useful study habits for first-year students.
-->

_To be developed by the assigned contributor._

## Useful Resources

<!--
Add only resources that have been checked for accuracy and relevance.

Example format:
- [Resource Name](https://example.com) — One-sentence explanation of why the resource is useful.

Prefer official university, department, course, or other authoritative resources when possible.
-->

_To be developed by the assigned contributor._
