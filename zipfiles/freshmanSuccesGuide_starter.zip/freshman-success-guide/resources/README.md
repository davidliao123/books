# Resources

This folder contains supporting resources for the **Freshman Success Guide**.

> **Student contributor:** Add files to this folder only when they are part of your assigned contribution or have been approved by your instructor. Follow the project conventions in `STYLE_GUIDE.md` and the workflow in `CONTRIBUTING.md`.

## Purpose of This Folder

Use the `resources/` folder for supporting files that help readers use or understand the guide but do not belong directly in one of the main Markdown sections.

Examples may include:

- checklists;
- worksheets;
- planning templates;
- reference documents;
- approved handouts;
- other supporting materials requested by the instructor.

Do not use this folder as a general place for unrelated downloads or personal files.

## Before Adding a Resource

Before adding a file:

- confirm that it is relevant to your assigned contribution;
- make sure your instructor permits the file type;
- verify that the information is accurate and current;
- confirm that you have permission to share the file;
- remove private or sensitive information;
- use a clear, descriptive filename;
- keep the file size reasonable.

## File Names

Use short, descriptive filenames.

Prefer lowercase letters and hyphens when possible.

Examples:

```text
weekly-planning-template.pdf
career-fair-checklist.pdf
study-session-planner.md
```

Avoid vague or version-based filenames such as:

```text
document1.pdf
resource-final.pdf
resource-final2.pdf
new-resource.pdf
```

Git should record changes over time instead of relying on manually renamed copies.

## File Types

Prefer simple, accessible, and widely supported file formats.

Depending on the assignment, appropriate formats may include:

```text
.md
.txt
.pdf
.csv
```

Use other file types only when they are necessary and approved by your instructor.

Whenever possible, prefer text-based formats such as Markdown because Git can display their changes clearly.

## Linking to a Resource

When linking from a Markdown file in the repository root, use a relative link.

For example:

```markdown
[Weekly Planning Template](resources/weekly-planning-template.pdf)
```

Use descriptive link text that tells readers what the resource contains.

Avoid:

```markdown
[click here](resources/weekly-planning-template.pdf)
```

## Verify Resource Content

Before committing a resource:

- open the file;
- confirm that it is the correct version;
- check that it is readable;
- verify links or references contained in the file;
- make sure the information matches the guide;
- remove outdated or unnecessary content.

Do not add a file that you have not reviewed yourself.

## Copyright and Permissions

Do not upload materials simply because they are available online.

A resource should be:

- created by you;
- provided or approved by your instructor;
- licensed for the intended use; or
- otherwise permitted for inclusion in the repository.

When attribution is required, follow your instructor's directions.

Instead of uploading a copyrighted document when redistribution is not permitted, link to its official webpage when appropriate.

## Institution-Specific Resources

Campus information can change.

Before adding a resource containing information such as:

- office names;
- contact information;
- schedules;
- deadlines;
- policies;
- degree requirements;
- service hours;

verify that the information is current.

When possible, link to an official university webpage rather than creating a duplicate document that may become outdated.

## Accessibility

Resources should be usable by as many readers as possible.

When creating or selecting a resource:

- use clear headings and readable text;
- provide meaningful link text;
- avoid relying only on color;
- keep tables and layouts simple;
- use accessible document formats when possible;
- include text equivalents for important visual information when appropriate.

## Sensitive Information

Never add files containing:

- passwords;
- authentication codes;
- access tokens;
- private keys;
- recovery codes;
- student identification numbers;
- private grades;
- confidential records;
- personal addresses;
- private information about another person.

If sensitive information is accidentally committed, notify your instructor immediately.

## Do Not Store Personal Working Files Here

Do not commit:

- private notes;
- rough drafts that are not part of the project;
- backup copies;
- unrelated downloads;
- temporary files;
- duplicate versions of the same resource.

Keep personal working files outside the repository.

## Before Committing a Resource

Confirm that:

- [ ] The resource supports my assigned contribution.
- [ ] My instructor permits this type of file.
- [ ] I reviewed the complete file.
- [ ] The information is accurate and current.
- [ ] I have permission to share it.
- [ ] The filename is descriptive.
- [ ] The file is stored in the `resources/` folder.
- [ ] The file size is reasonable.
- [ ] Any Markdown link to the resource works correctly.
- [ ] The resource does not contain private or sensitive information.
