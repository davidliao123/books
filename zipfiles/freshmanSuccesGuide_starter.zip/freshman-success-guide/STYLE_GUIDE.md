# Freshman Success Guide Style Guide

This document defines the writing, Markdown, and formatting conventions for the **Freshman Success Guide**.

The goal is to keep contributions clear, consistent, practical, and easy for future first-year students to read.

> **Student contributor:** Follow this guide when writing or revising your assigned section. Also follow the workflow in `CONTRIBUTING.md` and any additional instructions from your instructor.

## 1. Write for First-Year Students

Assume that the reader is a new student who may be unfamiliar with college expectations, university terminology, or technical vocabulary.

Write in a way that is:

- clear;
- welcoming;
- practical;
- specific;
- concise;
- respectful.

Avoid assuming that readers already know how college systems, academic departments, or technical tools work.

## 2. Give Practical Advice

Prefer concrete guidance over vague statements.

Less useful:

```text
Manage your time effectively.
```

More useful:

```text
At the beginning of each week, review upcoming assignments and exams. Add major deadlines to your calendar and divide large assignments into smaller tasks that can be completed over several days.
```

Whenever possible, explain what the student should actually do.

## 3. Keep the Tone Professional and Supportive

Use a friendly but professional tone.

Prefer:

```text
If you are unsure about an assignment, ask your instructor for clarification before the deadline.
```

Avoid:

```text
You should already know this.
```

Do not use language that is insulting, dismissive, overly casual, or unnecessarily dramatic.

## 4. Use Clear and Direct Language

Prefer short, direct sentences.

Avoid unnecessary jargon, complicated wording, and long introductions.

Prefer:

```text
Check the syllabus before contacting your instructor about a deadline.
```

Instead of:

```text
Students are encouraged to make use of the syllabus as a potentially valuable source of information regarding important course-related deadlines.
```

## 5. Use Second Person When Giving Advice

When addressing the reader directly, use **you**.

Example:

```text
Check your university email regularly so that you do not miss important course announcements.
```

Avoid switching unnecessarily between `you`, `students`, `one`, and other forms within the same section.

## 6. Organize Content with Headings

Use Markdown headings to organize ideas.

Use one level-one heading (`#`) for the title of each file.

Example:

```markdown
# Study Strategies
```

Use level-two headings (`##`) for major sections.

```markdown
## Studying for Exams
```

Use level-three headings (`###`) only when a subsection is genuinely needed.

```markdown
### One Week Before the Exam
```

Do not skip heading levels.

Avoid:

```markdown
# Main Title
#### Subsection
```

## 7. Keep Headings Short and Descriptive

Headings should help readers quickly understand what a section contains.

Prefer:

```markdown
## Using Office Hours
```

Avoid:

```markdown
## Some Important Things You Should Know About Going to Your Instructor's Office Hours
```

Use title-style capitalization consistently for major headings.

## 8. Keep Paragraphs Readable

Use relatively short paragraphs.

A paragraph should usually focus on one main idea. If a paragraph becomes difficult to scan, consider dividing it into two paragraphs or using a list.

Leave one blank line between paragraphs.

## 9. Use Lists When They Improve Clarity

Use bullet lists for items that do not need to appear in a specific order.

```markdown
Bring the following to a tutoring session:

- your notes;
- the assignment instructions;
- examples of problems you attempted;
- specific questions.
```

Use numbered lists when order matters.

```markdown
To prepare for registration:

1. Review your degree requirements.
2. Check prerequisite courses.
3. Meet with your advisor.
4. Prepare a tentative schedule.
```

Do not create a list when one short sentence would be clearer.

## 10. Keep List Items Parallel

Items in the same list should use a similar grammatical structure.

Prefer:

```markdown
- review your notes;
- complete practice problems;
- identify difficult topics;
- ask questions before the exam.
```

Avoid:

```markdown
- review your notes;
- practice problems;
- difficult topics should be identified;
- asking questions.
```

## 11. Use Bold Sparingly

Use bold text to emphasize a term or short phrase when it improves readability.

```markdown
Always verify **time-sensitive information** before adding it to the guide.
```

Do not bold entire paragraphs or use bold repeatedly for decoration.

## 12. Use Italics Sparingly

Use italics for limited emphasis when appropriate.

```markdown
Do not wait until the *night before* an exam to begin studying.
```

Do not rely on italics to communicate information that should instead be stated clearly.

## 13. Format File Names and Commands as Code

Use backticks for:

- filenames;
- folder names;
- commands;
- branch names;
- short code fragments;
- software elements when appropriate.

Examples:

```markdown
Open `README.md`.

Run `git status`.

Create a branch named `study-strategies`.
```

Use fenced code blocks for commands or examples that require multiple lines.

```markdown
```text
git status
git add study-strategies.md
git commit -m "Add exam preparation strategies"
```
```

## 14. Use Descriptive Link Text

Do not use vague link text such as:

```markdown
[click here](https://example.com)
```

Prefer:

```markdown
[University Academic Advising](https://example.com)
```

The link text should tell readers where the link goes.

## 15. Verify Every External Link

Before submitting your contribution:

- open every external link;
- confirm that the page still exists;
- confirm that the page contains the information you describe;
- prefer official or authoritative sources;
- verify time-sensitive information.

Do not include a link simply because an AI tool, search engine, or another person suggested it.

## 16. Prefer Authoritative Sources

When including factual or institution-specific information, prefer sources such as:

- official university webpages;
- official department webpages;
- course materials;
- official government resources;
- recognized professional organizations;
- official software documentation.

Avoid relying on unverified blogs, social-media posts, anonymous forums, or outdated webpages when authoritative information is available.

## 17. Be Careful with Institution-Specific Information

Campus information can change.

Before adding details such as:

- office names;
- office locations;
- hours;
- phone numbers;
- policies;
- deadlines;
- program requirements;
- tutoring schedules;

verify that the information is current.

When possible, link to the official page instead of copying information that may quickly become outdated.

## 18. Avoid Unsupported Claims

Do not present opinions, assumptions, or unverified advice as established facts.

Avoid statements such as:

```text
This is the best way to study for every exam.
```

Prefer:

```text
Practice problems can help you identify which topics you understand and which topics need additional review.
```

## 19. Do Not Invent Information

If you cannot verify a detail, do not guess.

This applies especially to:

- campus services;
- policies;
- deadlines;
- statistics;
- contact information;
- academic requirements;
- software features;
- AI policies.

Ask your instructor or leave the information out until it can be verified.

## 20. Use Examples Carefully

Examples should clarify the advice without pretending to describe an official requirement.

Example:

```markdown
A student might divide a research assignment into smaller tasks such as choosing a topic, locating sources, creating an outline, drafting, and revising.
```

Make it clear when something is an example rather than a required process.

## 21. Use Tables Only When They Help

Tables are useful for compact comparisons or structured information.

Example:

```markdown
| Resource | Best Used For |
|---|---|
| Academic advising | Degree planning and registration |
| Tutoring | Help with course concepts and practice |
| Career services | Resumes, internships, and interviews |
```

Do not use a table when a short paragraph or list would be easier to read.

Keep tables reasonably narrow so they display well on different screens.

## 22. Images

Only add images when they are approved or required.

Place project images in the `images/` folder.

Use descriptive filenames such as:

```text
weekly-planning-example.png
```

Avoid vague filenames such as:

```text
image1.png
```

When adding an image in Markdown, include meaningful alternative text.

```markdown
![Example of a weekly study schedule](images/weekly-planning-example.png)
```

Do not use filenames as alternative text unless they meaningfully describe the image.

## 23. Accessibility

Write and format content so that it is usable by as many readers as possible.

When appropriate:

- use meaningful headings;
- use descriptive link text;
- include alternative text for images;
- do not rely only on color to communicate meaning;
- keep tables simple;
- avoid unnecessarily complex layouts;
- use clear language.

## 24. Avoid Sensitive or Private Information

Never include:

- passwords;
- authentication codes;
- access tokens;
- recovery codes;
- private keys;
- student identification numbers;
- private grades;
- confidential records;
- personal addresses;
- private information about another person.

If you are unsure whether information is appropriate to publish in the repository, ask your instructor.

## 25. Responsible Use of AI

Follow the instructor's rules for AI use on this project.

If AI assistance is permitted:

- use it to support your work rather than replace your judgment;
- verify factual claims;
- verify links and sources yourself;
- check generated Markdown;
- revise generated text so that it fits the guide;
- make sure you understand everything you submit;
- disclose AI assistance if required.

Do not assume that AI-generated information is accurate.

## 26. Avoid Unnecessary Repetition

Before adding content, check whether the same advice already appears elsewhere in the guide.

When another file covers the topic in more detail, refer readers to it.

Example:

```markdown
For additional information about tutoring and advising, see [Campus Resources](campus-resources.md).
```

This keeps the guide organized and prevents several files from repeating the same information.

## 27. Use Relative Links for Repository Files

When linking to another file in this repository, use a relative link.

Example:

```markdown
[Study Strategies](study-strategies.md)
```

For a file inside a folder:

```markdown
[Image Guidelines](images/README.md)
```

This keeps repository links portable.

## 28. Keep File and Folder Names Consistent

Do not rename project files or folders unless your instructor approves the change.

Repository filenames use lowercase letters and hyphens when appropriate.

Examples:

```text
study-strategies.md
career-preparation.md
responsible-ai-use.md
```

Avoid creating alternate versions such as:

```text
study-strategies-final.md
study-strategies-new.md
study-strategies-final2.md
```

Git should record the history instead of manually renamed copies.

## 29. Review Before Committing

Before committing your work:

- reread the entire section you changed;
- preview the Markdown if possible;
- check headings and lists;
- check spelling and grammar;
- verify links;
- verify factual claims;
- remove placeholder text that belongs to your assigned section;
- confirm that you did not change unrelated content.

Use Git or Visual Studio Code to inspect the differences before committing.

## 30. Final Style Checklist

Before submitting your pull request, confirm that:

- [ ] I wrote for a first-year student audience.
- [ ] My advice is specific and practical.
- [ ] My tone is clear, professional, and supportive.
- [ ] I used headings consistently.
- [ ] My paragraphs and lists are easy to read.
- [ ] I formatted filenames and commands with backticks.
- [ ] My links use descriptive text.
- [ ] I opened and verified every external link.
- [ ] I verified institution-specific and time-sensitive information.
- [ ] I did not invent or guess factual information.
- [ ] I avoided unnecessary repetition.
- [ ] I did not include sensitive or private information.
- [ ] I followed any instructor requirements for AI use.
- [ ] I previewed and reviewed my Markdown before submitting it.
